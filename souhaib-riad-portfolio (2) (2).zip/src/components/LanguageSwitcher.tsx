import { motion, AnimatePresence } from 'motion/react';
import { Globe } from 'lucide-react';
import { Language } from '../translations';

interface Props {
  currentLang: Language;
  setLang: (lang: Language) => void;
  isDarkBackground?: boolean;
}

export default function LanguageSwitcher({ currentLang, setLang, isDarkBackground }: Props) {
  const languages: { code: Language; label: string }[] = [
    { code: 'en', label: 'English' },
    { code: 'fr', label: 'Français' },
    { code: 'ar', label: 'العربية' },
  ];

  return (
    <div className={`flex items-center gap-2 p-1 rounded-full backdrop-blur-sm border transition-colors ${
      isDarkBackground 
        ? 'bg-white/10 border-white/10' 
        : 'bg-navy-900/10 border-navy-900/5'
    }`}>
      {languages.map((lang) => (
        <button
          key={lang.code}
          onClick={() => setLang(lang.code)}
          className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
            currentLang === lang.code
              ? isDarkBackground ? 'bg-white text-navy-900 shadow-md' : 'bg-navy-900 text-white shadow-md'
              : isDarkBackground ? 'text-white hover:bg-white/10' : 'text-navy-900 hover:bg-navy-900/5'
          }`}
        >
          {lang.label}
        </button>
      ))}
    </div>
  );
}
