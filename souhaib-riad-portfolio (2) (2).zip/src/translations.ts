export type Language = 'en' | 'fr' | 'ar';

export const translations = {
  en: {
    nav: {
      about: 'About',
      skills: 'Skills',
      experience: 'Experience',
      services: 'Services',
      contact: 'Contact',
    },
    hero: {
      greeting: 'Hello, I’m',
      name: 'Souhaib Riad',
      title: 'Freelance Digital Marketer & Commerce Student',
      subtitle: 'Helping businesses grow through digital marketing and social media strategies.',
      viewWork: 'View My Work',
      contactMe: 'Contact Me',
    },
    about: {
      title: 'About Me',
      content: 'I am a motivated and passionate student in Gestion, Commerce and Marketing with experience in sales and digital marketing. I currently work as a freelance digital marketer specialized in social media marketing, helping businesses improve their online visibility and growth. Passionate about commerce, communication, and business development.',
    },
    skills: {
      title: 'My Expertise',
    },
    experience: {
      title: 'Professional Journey',
      freelance: {
        title: 'Freelance Digital Marketer',
        items: ['Social Media Marketing', 'Brand Growth', 'Marketing Strategies', 'Customer Engagement', 'Online Promotion'],
      },
      sales: {
        title: 'Sales Experience',
        items: ['Customer Communication', 'Product Promotion', 'Selling Skills', 'Customer Relations'],
      },
    },
    education: {
      title: 'Education',
      studies: 'Gestion, Commerce & Marketing Student',
      diploma: 'Bacalaureate Diploma',
    },
    languages: {
      title: 'Languages',
      arabic: 'Arabic',
      english: 'English',
      french: 'French',
      levels: {
        native: 'Native',
        excellent: 'Excellent',
        good: 'Good',
      }
    },
    services: {
      title: 'Our Services',
      sm: 'Social Media Marketing',
      consultation: 'Marketing Consultation',
      growth: 'Brand Growth',
      promotion: 'Online Promotion',
    },
    contact: {
      title: 'Get In Touch',
      subtitle: 'Let’s work together to grow your business.',
      form: {
        name: 'Full Name',
        email: 'Email Address',
        message: 'Your Message',
        send: 'Send Message',
      },
      footer: '© 2026 Souhaib Riad – All Rights Reserved',
    },
  },
  fr: {
    nav: {
      about: 'À propos',
      skills: 'Compétences',
      experience: 'Expérience',
      services: 'Services',
      contact: 'Contact',
    },
    hero: {
      greeting: 'Bonjour, je suis',
      name: 'Souhaib Riad',
      title: 'Marketeur Digital Freelance & Étudiant en Commerce',
      subtitle: 'J’aide les entreprises à se développer grâce au marketing digital et aux stratégies de médias sociaux.',
      viewWork: 'Voir mon travail',
      contactMe: 'Contactez-moi',
    },
    about: {
      title: 'À propos de moi',
      content: 'Je suis un étudiant motivé et passionné en Gestion, Commerce et Marketing avec une expérience en vente et marketing digital. Je travaille actuellement en tant que marketeur digital freelance spécialisé dans le marketing des médias sociaux, aidant les entreprises à améliorer leur visibilité en ligne et leur croissance. Passionné par le commerce, la communication et le développement des affaires.',
    },
    skills: {
      title: 'Mon Expertise',
    },
    experience: {
      title: 'Parcours Professionnel',
      freelance: {
        title: 'Marketeur Digital Freelance',
        items: ['Marketing des médias sociaux', 'Croissance de marque', 'Stratégies marketing', 'Engagement client', 'Promotion en ligne'],
      },
      sales: {
        title: 'Expérience en Vente',
        items: ['Communication client', 'Promotion de produit', 'Techniques de vente', 'Relations clients'],
      },
    },
    education: {
      title: 'Éducation',
      studies: 'Étudiant en Gestion, Commerce & Marketing',
      diploma: 'Diplôme du Baccalauréat',
    },
    languages: {
      title: 'Langues',
      arabic: 'Arabe',
      english: 'Anglais',
      french: 'Français',
      levels: {
        native: 'Maternel',
        excellent: 'Excellent',
        good: 'Bien',
      }
    },
    services: {
      title: 'Nos Services',
      sm: 'Marketing des médias sociaux',
      consultation: 'Consultation Marketing',
      growth: 'Croissance de marque',
      promotion: 'Promotion en ligne',
    },
    contact: {
      title: 'Contactez-moi',
      subtitle: 'Travaillons ensemble pour faire croître votre entreprise.',
      form: {
        name: 'Nom complet',
        email: 'Adresse e-mail',
        message: 'Votre message',
        send: 'Envoyer le message',
      },
      footer: '© 2026 Souhaib Riad – Tous droits réservés',
    },
  },
  ar: {
    nav: {
      about: 'حول',
      skills: 'المهارات',
      experience: 'الخبرة',
      services: 'الخدمات',
      contact: 'اتصل بي',
    },
    hero: {
      greeting: 'مرحباً، أنا',
      name: 'صهيب رياض',
      title: 'مسوق رقمي مستقل وطالب في التجارة',
      subtitle: 'مساعدة الشركات على النمو من خلال التسويق الرقمي واستراتيجيات وسائل التواصل الاجتماعي.',
      viewWork: 'شاهد أعمالي',
      contactMe: 'اتصل بي',
    },
    about: {
      title: 'حول شخصي',
      content: 'أنا طالب متحمس وطموح في تسيير المقاولات، التجارة والتسويق، لدي خبرة في المبيعات والتسويق الرقمي. أعمل حالياً كمبرمج ومسوق رقمي مستقل متخصص في التسويق عبر وسائل التواصل الاجتماعي، حيث أساعد الشركات على تحسين تواجدها عبر الإنترنت ونموها. شغوف بالتجارة والتواصل وتطوير الأعمال.',
    },
    skills: {
      title: 'خبراتي',
    },
    experience: {
      title: 'المسار المهني',
      freelance: {
        title: 'مسوق رقمي مستقل',
        items: ['التسويق عبر وسائل التواصل الاجتماعي', 'نمو العلامة التجارية', 'استراتيجيات التسويق', 'تفاعل العملاء', 'الترويج عبر الإنترنت'],
      },
      sales: {
        title: 'خبرة في المبيعات',
        items: ['التواصل مع العملاء', 'الترويج للمنتجات', 'مهارات البيع', 'علاقات العملاء'],
      },
    },
    education: {
      title: 'التعليم',
      studies: 'طالب في تسيير المقاولات، التجارة والتسويق',
      diploma: 'شهادة البكالوريا (2024)',
    },
    languages: {
      title: 'اللغات',
      arabic: 'العربية',
      english: 'الإنجليزية',
      french: 'الفرنسية',
      levels: {
        native: 'اللغة الأم',
        excellent: 'ممتاز',
        good: 'جيد',
      }
    },
    services: {
      title: 'خدماتنا',
      sm: 'التسويق عبر وسائل التواصل الاجتماعي',
      consultation: 'استشارات تسويقية',
      growth: 'نمو العلامة التجارية',
      promotion: 'الترويج عبر الإنترنت',
    },
    contact: {
      title: 'ابق على تواصل',
      subtitle: 'دعونا نعمل معاً لتنمية عملك.',
      form: {
        name: 'الاسم الكامل',
        email: 'البريد الإلكتروني',
        message: 'رسالتك',
        send: 'إرسال الرسالة',
      },
      footer: '© 2026 صهيب رياض – جميع الحقوق محفوظة',
    },
  },
};
