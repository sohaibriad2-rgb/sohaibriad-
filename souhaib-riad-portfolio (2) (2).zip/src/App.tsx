/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Instagram, 
  Mail, 
  Phone, 
  ExternalLink, 
  CheckCircle2, 
  Code, 
  TrendingUp, 
  Users, 
  BarChart3, 
  MessageSquare,
  ChevronRight,
  GraduationCap,
  Briefcase,
  Globe2,
  Award,
  Menu,
  X
} from 'lucide-react';
import { translations, Language } from './translations';
import LanguageSwitcher from './components/LanguageSwitcher';
import souhaibImg from './assets/images/souhaib.jpeg';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = translations[lang];
  const isRTL = lang === 'ar';

  // State for scroll animations
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6, ease: "easeOut" } }
  };

  const skillsData = [
    { name: 'Social Media Marketing', icon: TrendingUp },
    { name: 'Digital Marketing', icon: BarChart3 },
    { name: 'Sales', icon: Briefcase },
    { name: 'Commerce', icon: Award },
    { name: 'Marketing Strategy', icon: Globe2 },
    { name: 'Communication', icon: MessageSquare },
  ];

  return (
    <div className={`min-h-screen selection:bg-accent/30 ${isRTL ? 'font-sans' : 'font-sans'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/80 backdrop-blur-lg border-b border-navy-900/10 py-3' : 'bg-transparent py-5'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className={`text-2xl font-serif font-bold transition-colors ${scrolled ? 'text-navy-900' : 'text-white'}`}
          >
            S.Riad
          </motion.div>
          <div className="flex items-center gap-4 md:gap-8">
            <div className="hidden md:flex items-center gap-6">
              {Object.entries(t.nav).map(([key, label]) => (
                <a 
                  key={key} 
                  href={`#${key}`} 
                  className={`text-sm font-medium transition-colors ${
                    scrolled ? 'text-navy-900/70 hover:text-navy-900' : 'text-white/70 hover:text-white'
                  }`}
                >
                  {label}
                </a>
              ))}
            </div>
            
            <div className="hidden sm:block">
              <LanguageSwitcher currentLang={lang} setLang={setLang} isDarkBackground={!scrolled} />
            </div>

            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`p-2 rounded-lg md:hidden transition-colors ${scrolled ? 'text-navy-900 hover:bg-navy-900/5' : 'text-white hover:bg-white/10'}`}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile menu overlay */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-full left-0 right-0 bg-white border-b border-navy-900/10 p-6 md:hidden shadow-2xl"
            >
              <div className="flex flex-col gap-6">
                {Object.entries(t.nav).map(([key, label]) => (
                  <a 
                    key={key} 
                    href={`#${key}`} 
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-lg font-medium text-navy-900 hover:text-accent transition-colors"
                  >
                    {label}
                  </a>
                ))}
                <div className="pt-4 border-t border-navy-900/5 flex justify-between items-center">
                  <span className="text-sm font-semibold text-navy-900/40 uppercase tracking-wider">{t.languages.title}</span>
                  <LanguageSwitcher currentLang={lang} setLang={setLang} isDarkBackground={false} />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <main>
        {/* Hero Section */}
        <section id="hero" className="relative h-screen flex items-center overflow-hidden mesh-gradient">
          {/* Floating background decorative elements */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <motion.div 
              animate={{ 
                x: [0, 50, 0], 
                y: [0, 100, 0],
                rotate: [0, 90, 0]
              }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute -top-24 -left-24 w-96 h-96 bg-accent/10 rounded-full blur-3xl"
            />
            <motion.div 
              animate={{ 
                x: [0, -50, 0], 
                y: [0, -100, 0],
                rotate: [0, -90, 0]
              }}
              transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
              className="absolute -bottom-24 -right-24 w-[500px] h-[500px] bg-sky-500/10 rounded-full blur-3xl"
            />
          </div>

          <div className="absolute inset-0 z-0">
             <img 
               src="/src/assets/images/hero_marketing_background_1779206735690.png" 
               alt="Background" 
               className="w-full h-full object-cover opacity-20 mix-blend-lighten scale-110"
               referrerPolicy="no-referrer"
             />
             <div className="absolute inset-0 bg-gradient-to-t from-navy-900 via-navy-900/40 to-transparent" />
          </div>
          
          <div className="relative z-10 max-w-7xl mx-auto px-6 w-full">
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={containerVariants}
              className="max-w-2xl"
            >
              <motion.span variants={itemVariants} className="inline-block px-4 py-1.5 rounded-full bg-accent/20 border border-accent/30 text-white text-xs font-semibold tracking-wider uppercase mb-6 backdrop-blur-sm">
                {t.hero.greeting}
              </motion.span>
              <motion.h1 
                variants={itemVariants}
                className="text-6xl md:text-8xl font-serif font-bold text-white leading-tight mb-6 drop-shadow-sm"
              >
                {t.hero.name}
              </motion.h1>
              <motion.p 
                variants={itemVariants}
                className="text-xl md:text-2xl text-white/80 font-light mb-8 max-w-lg"
              >
                {t.hero.title}
              </motion.p>
              <motion.p 
                variants={itemVariants}
                className="text-lg text-white/60 mb-10 leading-relaxed italic border-l-2 border-accent/50 pl-6"
              >
                "{t.hero.subtitle}"
              </motion.p>
              <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4">
                <a href="#experience" className="px-8 py-4 bg-accent text-white rounded-full font-semibold hover:bg-accent/90 transition-all text-center shadow-lg shadow-accent/25">
                  {t.hero.viewWork}
                </a>
                <a href="#contact" className="px-8 py-4 bg-white/5 border border-white/20 text-white rounded-full font-semibold hover:bg-white hover:text-navy-900 transition-all text-center backdrop-blur-sm">
                  {t.hero.contactMe}
                </a>
              </motion.div>
            </motion.div>
          </div>
          
          {/* Decorative scroll indicator */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2, duration: 1 }}
            className="absolute bottom-10 left-1/2 -translate-x-1/2"
          >
            <div className="flex flex-col items-center gap-4">
              <span className="text-[10px] uppercase tracking-[0.4em] text-white/40 rotate-180" style={{ writingMode: 'vertical-rl' }}>Scroll</span>
              <div className="w-px h-12 bg-gradient-to-b from-accent to-transparent" />
            </div>
          </motion.div>
        </section>

        {/* About Section */}
        <section id="about" className="py-24 md:py-32 bg-white subtle-mesh relative overflow-hidden">
          {/* Subtle background blob */}
          <div className="absolute top-1/2 left-0 -translate-y-1/2 w-64 h-64 bg-accent/5 rounded-full blur-3xl pointer-events-none" />
          <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 lg:gap-20 items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl group"
            >
              <div className="absolute inset-0 bg-navy-900/10 group-hover:bg-transparent transition-colors duration-500 z-10" />
              <img 
                src={souhaibImg} 
                alt="Souhaib Riad" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=1000";
                }}
                referrerPolicy="no-referrer"
              />
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="p-8 md:p-12 rounded-3xl glass-card relative z-10"
            >
              <h2 className="text-4xl md:text-5xl font-serif font-bold mb-8 text-navy-900 relative">
                {t.about.title}
                <span className={`absolute -bottom-4 ${isRTL ? 'right-0' : 'left-0'} w-20 h-1 bg-accent rounded-full`} />
              </h2>
              <div className="text-lg md:text-xl text-navy-900/70 leading-relaxed space-y-6">
                <p>{t.about.content}</p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Skills Grid */}
        <section id="skills" className="py-32 bg-navy-900 text-white overflow-hidden">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-20">
              <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">{t.skills.title}</h2>
              <div className="w-24 h-1 bg-accent mx-auto rounded-full" />
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {skillsData.map((skill, index) => (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -5, transition: { duration: 0.2 } }}
                  className="p-8 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm group hover:bg-white/10 transition-colors"
                >
                  <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center mb-6 group-hover:bg-accent transition-colors">
                    <skill.icon className="w-6 h-6 text-accent group-hover:text-white transition-colors" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{skill.name}</h3>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Experience & Education */}
        <section id="experience" className="py-32 bg-gray-50">
          <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-20">
            {/* Experience */}
            <div>
              <div className="flex items-center gap-4 mb-12">
                <Briefcase className="w-8 h-8 text-accent" />
                <h2 className="text-4xl font-serif font-bold text-navy-900">{t.experience.title}</h2>
              </div>
              
              <div className="space-y-12">
                <div className="relative pl-8 border-l border-navy-900/10">
                  <div className="absolute top-0 -left-1.5 w-3 h-3 rounded-full bg-accent" />
                  <h3 className="text-2xl font-serif font-bold text-navy-900 mb-4">{t.experience.freelance.title}</h3>
                  <div className="flex flex-wrap gap-2">
                    {t.experience.freelance.items.map(item => (
                      <span key={item} className="px-3 py-1 rounded-full bg-white border border-navy-900/5 text-sm text-navy-900/70 shadow-sm">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="relative pl-8 border-l border-navy-900/10">
                  <div className="absolute top-0 -left-1.5 w-3 h-3 rounded-full bg-accent" />
                  <h3 className="text-2xl font-serif font-bold text-navy-900 mb-4">{t.experience.sales.title}</h3>
                  <div className="flex flex-wrap gap-2">
                    {t.experience.sales.items.map(item => (
                      <span key={item} className="px-3 py-1 rounded-full bg-white border border-navy-900/5 text-sm text-navy-900/70 shadow-sm">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Education & Languages */}
            <div className="space-y-20">
              {/* Education */}
              <div>
                <div className="flex items-center gap-4 mb-12">
                  <GraduationCap className="w-8 h-8 text-accent" />
                  <h2 className="text-4xl font-serif font-bold text-navy-900">{t.education.title}</h2>
                </div>
                <div className="space-y-6">
                  <div className="p-6 rounded-2xl bg-white shadow-sm border border-navy-900/5">
                    <h3 className="text-xl font-bold text-navy-900 mb-1">{t.education.studies}</h3>
                    <p className="text-navy-900/60 text-sm">Present</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-white shadow-sm border border-navy-900/5">
                    <h3 className="text-xl font-bold text-navy-900 mb-1">{t.education.diploma}</h3>
                    <p className="text-navy-900/60 text-sm">Obtained in 2024</p>
                  </div>
                </div>
              </div>

              {/* Languages */}
              <div>
                <div className="flex items-center gap-4 mb-12">
                  <Globe2 className="w-8 h-8 text-accent" />
                  <h2 className="text-4xl font-serif font-bold text-navy-900">{t.languages.title}</h2>
                </div>
                <div className="space-y-8">
                  {[
                    { name: t.languages.arabic, level: t.languages.levels.native, percent: 100 },
                    { name: t.languages.english, level: t.languages.levels.excellent, percent: 95 },
                    { name: t.languages.french, level: t.languages.levels.good, percent: 75 },
                  ].map((lang) => (
                    <div key={lang.name}>
                      <div className="flex justify-between mb-2">
                        <span className="font-bold text-navy-900">{lang.name}</span>
                        <span className="text-sm text-navy-900/60">{lang.level}</span>
                      </div>
                      <div className="h-2 w-full bg-navy-900/5 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          whileInView={{ width: `${lang.percent}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1.5, ease: "easeOut" }}
                          className="h-full bg-accent"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Services */}
        <section id="services" className="py-32 bg-white">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-24">
              <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6 text-navy-900">{t.services.title}</h2>
              <div className="w-24 h-1 bg-accent mx-auto rounded-full" />
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { title: t.services.sm, icon: TrendingUp },
                { title: t.services.consultation, icon: Users },
                { title: t.services.growth, icon: BarChart3 },
                { title: t.services.promotion, icon: Globe2 },
              ].map((service, index) => (
                <motion.div
                  key={service.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="p-10 rounded-3xl bg-gray-50 hover:bg-white hover:shadow-xl hover:-translate-y-2 transition-all duration-300 border border-navy-900/5 group"
                >
                  <div className="w-14 h-14 rounded-2xl bg-white shadow-sm flex items-center justify-center mb-8 group-hover:bg-accent group-hover:text-white transition-colors duration-300">
                    <service.icon className="w-6 h-6 text-accent group-hover:text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-navy-900 mb-4">{service.title}</h3>
                  <div className="w-10 h-0.5 bg-accent/30 group-hover:w-full transition-all duration-500" />
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-24 md:py-32 bg-navy-900 text-white">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid lg:grid-cols-2 gap-16 lg:gap-20">
              <div>
                <h2 className="text-4xl md:text-5xl font-serif font-bold mb-8 leading-tight">
                  {t.contact.title}
                </h2>
                <p className="text-xl text-white/60 mb-12 leading-relaxed">
                  {t.contact.subtitle}
                </p>
                
                <div className="space-y-8">
                  <a href="tel:0669614950" className="flex items-center gap-6 group">
                    <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-accent group-hover:border-accent transition-all">
                      <Phone className="w-5 h-5 text-accent group-hover:text-white" />
                    </div>
                    <span className="text-lg font-medium">0669614950</span>
                  </a>
                  <a href="mailto:sohaibriad2@gmail.com" className="flex items-center gap-6 group">
                    <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-accent group-hover:border-accent transition-all">
                      <Mail className="w-5 h-5 text-accent group-hover:text-white" />
                    </div>
                    <span className="text-lg font-medium">sohaibriad2@gmail.com</span>
                  </a>
                  <a href="https://www.instagram.com/riad_0014/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-6 group">
                    <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-accent group-hover:border-accent transition-all">
                      <Instagram className="w-5 h-5 text-accent group-hover:text-white" />
                    </div>
                    <span className="text-lg font-medium">@riad_0014</span>
                  </a>
                </div>
              </div>
              
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="p-10 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-lg"
              >
                <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold opacity-70 uppercase tracking-wider">{t.contact.form.name}</label>
                    <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 focus:ring-2 focus:ring-accent outline-none transition-all" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold opacity-70 uppercase tracking-wider">{t.contact.form.email}</label>
                    <input type="email" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 focus:ring-2 focus:ring-accent outline-none transition-all" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold opacity-70 uppercase tracking-wider">{t.contact.form.message}</label>
                    <textarea rows={4} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 focus:ring-2 focus:ring-accent outline-none transition-all resize-none" />
                  </div>
                  <button type="submit" className="w-full py-5 bg-accent hover:bg-accent/90 text-white rounded-xl font-bold transition-all flex items-center justify-center gap-2">
                    {t.contact.form.send}
                    <ChevronRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                  </button>
                </form>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <footer className="py-12 bg-navy-900 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-2xl font-serif font-bold text-white">S.Riad</div>
          <p className="text-white/40 text-sm">
            {t.contact.footer}
          </p>
          <div className="flex items-center gap-6">
            <a href="https://www.instagram.com/riad_0014/" className="text-white/40 hover:text-white transition-colors">
              <Instagram className="w-5 h-5" />
            </a>
            <a href="mailto:sohaibriad2@gmail.com" className="text-white/40 hover:text-white transition-colors">
              <Mail className="w-5 h-5" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

